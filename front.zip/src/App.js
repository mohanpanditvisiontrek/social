import './App.css';
import { BrowserRouter,Route,Routes} from "react-router-dom"
import MainNavbar from './components/navbar';
import LeftBar from './components/home';
import { AuthProvider } from "./context/authProvider";
import Login from "./components/login";

function App() {
  return (
    <>
   <AuthProvider>
    <BrowserRouter>
    <Routes>
    
      <Route path='' element={ <Login/>}></Route>
      <Route path='home' element={ <MainNavbar/> }></Route>
      <Route path='mk' element={"ok done"}></Route>
    
    </Routes>
    </BrowserRouter>
    </AuthProvider>
    </>
  );
}

export default App;
