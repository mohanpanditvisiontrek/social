import { createContext, useState } from "react";
import jwt_decode from "jwt-decode";

const AuthContext = createContext();

export default AuthContext;

export const AuthProvider =({children})=>{


    const [user,setUser]=useState(null);

    let [authTokens,setToken]=useState(null)

    const loginUse= async (e)=>{
        e.preventDefault()
        console.log(e.target.email_phone.value);
        let response= await fetch('http://127.0.0.1:8000/user-login',{
            method:'POST',
            headers:{
                'content-type':'application/json'
            },
            body:JSON.stringify({'email_phone':e.target.email_phone.value,'password':e.target.password.value})
        })

        let data = await response.json()
        console.log(data);
        if(response.status===200){

            setToken(data)
            setUser(jwt_decode(data.access))

            console.log(jwt_decode(data.access))
        }
        else{
            alert("wrong");
        }
    }

    let contextData ={
        user:user,
        loginUser:loginUse

    }

    return(
        <AuthContext.Provider value={contextData}>
            {children}
        </AuthContext.Provider>
    )
}

