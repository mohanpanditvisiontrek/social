import { createContext } from "react";

const UserData = createContext(null);

export default UserData;